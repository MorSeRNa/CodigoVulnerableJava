// You can import from existing dependencies (see build.gradle)
// You cannot install new dependencies
// Solve the challenge using your own solution
// Look at the usability tests to find what is expected
// Look at the security tests to find what is NOT expected

package app;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;

@Controller
@EnableAutoConfiguration
@SpringBootApplication
public class Application {
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public static ResponseEntity main() {
		return new ResponseEntity<>("Hello,", HttpStatus.OK);
    }

    public static void main(String[] args) throws Exception {
        SpringApplication.run(Application.class, args);
        System.out.println("Navigate to http://localhost:8080/");
    }
}
