// You can import from existing dependencies (see build.gradle)
// You cannot install new dependencies
// Solve the challenge using your own solution
// Look at the usability tests to find what is expected
// Look at the security tests to find what is NOT expected

package app;

import java.util.Optional;
import java.io.StringWriter;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.File;
import java.util.Scanner;
import java.util.HashMap;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@Controller
@EnableAutoConfiguration
@SpringBootApplication
public class Application {
    @RequestMapping(value = "/status", method = RequestMethod.GET)
    public static ResponseEntity status() {
		return new ResponseEntity<>("", HttpStatus.OK);
    }

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public static ResponseEntity main() {
		return new ResponseEntity<>("Tell me who to say hello? e.g. /sayHello/?name=alice", HttpStatus.OK);
    }

    @RequestMapping(value = "/sayHello", method = RequestMethod.GET)
    public static ResponseEntity sayHello(@RequestParam(name="name",required=false) String name) throws Exception {
        if(name == null || name.equals("")){
            return new ResponseEntity<>("Tell me who to say hello? e.g. /sayHello/?name=alice", HttpStatus.OK);
        }
		return new ResponseEntity<>("<h1>Hello, "+name+"</h1>" , HttpStatus.OK);
    }

	

    public static void main(String[] args) throws Exception {
        SpringApplication.run(Application.class, args);
        System.out.println("Navigate to http://localhost:8080/");
    }
}