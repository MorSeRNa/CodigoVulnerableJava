// You can import from existing dependencies (see build.gradle)
// You cannot install new dependencies
// Solve the challenge using your own solution
// Look at the usability tests to find what is expected
// Look at the security tests to find what is NOT expected

package app;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@Controller
@EnableAutoConfiguration
@SpringBootApplication
public class Application {
    private static Connection connection = null;
    private static Statement statement = null;
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public static ResponseEntity index() {
		return new ResponseEntity<>("[!] Welcome to the admin portal!<br>[?] Please login here http://localhost:8080/login?username=admin&password=supers3cret: ", HttpStatus.OK);
    }

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public static ResponseEntity login(@RequestParam(name="username", required=false) String username, @RequestParam(name="password", required=false) String password) throws Exception {
		createDatabaseConnection();
        ResultSet queryResult = statement.executeQuery("select * from users where username = '"+username+"' AND password = '"+password+"'");
        while(queryResult.next())
        {
            return new ResponseEntity<>("[i] Logged in as "+queryResult.getString("username"), HttpStatus.OK);
        }
        return new ResponseEntity<>("[i] Failed to log in as "+username+", please try again" , HttpStatus.OK);
    } 

    public static void main(String[] args) throws Exception {
        createDatabaseConnection();
        SpringApplication.run(Application.class, args);
        System.out.println("Navigate to http://localhost:8080/");
    }

    private static void createDatabaseConnection(){
        if(connection == null || statement == null){
            Logger logger = Logger.getLogger("logger");
            try
            {
                // create a database connection
                connection = DriverManager.getConnection("jdbc:sqlite:users.db");
                statement = connection.createStatement();
                statement.setQueryTimeout(30);  // set timeout to 30 sec.

                statement.executeUpdate("drop table if exists users");
                statement.executeUpdate("create table users (username string, password string)");
                statement.executeUpdate("insert into users values('admin', 'supers3cret')");
            }
            catch(SQLException e)
            {
            logger.info(e.getMessage());
            }
        }
    }
}