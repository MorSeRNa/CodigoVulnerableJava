package app;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.Random;


@DisplayName("Security tests")
@WebMvcTest
@Tag("security")
public class appSecuritySpec {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void test_handle_SQL_injection_payload_with_return_fail() throws Exception {
        this.mockMvc.perform(get("/login").param("username", "admin' OR 1=1 --"))
        .andExpect(status().isOk()).andExpect(content().string(containsString("[i] Failed to log in as admin' OR 1=1 --, please try again")));
    }
}
