package app;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.hamcrest.CoreMatchers.*;

@DisplayName("Usability unit tests")
@WebMvcTest
public class appSpec {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void test_should_call_GET_and_return_status_code_200() throws Exception {
        this.mockMvc.perform(get("/"))
        .andExpect(status().isOk());
    }

    @Test
    public void test_correct_username_and_password_should_return_success() throws Exception {
        this.mockMvc.perform(get("/login").param("username", "admin").param("password", "supers3cret"))
        .andExpect(status().isOk()).andExpect(content().string(containsString("[i] Logged in as admin")));
    }

    @Test
    public void test_incorrect_username_and_password_should_return_failed() throws Exception {
        this.mockMvc.perform(get("/login").param("username", "admin").param("password", "badpassword"))
        .andExpect(status().isOk()).andExpect(content().string(containsString("[i] Failed to log in as admin, please try again")));
    }

    @Test
    public void test_GET_without_password_should_return_fail() throws Exception {
        this.mockMvc.perform(get("/login").param("username", "admin"))
        .andExpect(status().isOk()).andExpect(content().string(containsString("[i] Failed to log in as admin, please try again")));
    }

    @Test
    public void test_GET_without_username_should_return_fail() throws Exception {
        this.mockMvc.perform(get("/login").param("password", "supers3cret"))
        .andExpect(status().isOk()).andExpect(content().string(containsString("[i] Failed to log in as null, please try again")));
    }
}
